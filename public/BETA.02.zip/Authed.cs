﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net;
using System.Text;
using System.Timers;

public class Auth
{
    public User user { get; set; }
    private string SessionToken { get; set; }
    private string ShortTermToken { get; set; }
    public bool Authed { get; set; }
    private int lastCheck { get; set; }
    public bool IsLegit { get; set; }
    private string API_PREFIX = "https://authed.io/api";


    private Timer sessTimer, userUpdater;

    public Auth()
    {
        sessTimer = new Timer();
        sessTimer.Interval = 10000; //Every 10
        sessTimer.Elapsed += sessTimer_Elapsed;

        userUpdater = new Timer();
        userUpdater.Interval = 15000; //Every 15
        userUpdater.Elapsed += UserUpdater_Elapsed;

        sessTimer.Start();
        userUpdater.Start();
    }

    private void UserUpdater_Elapsed(object sender, ElapsedEventArgs e)
    {
        if (ShortTermToken != null)
        {
            GetUserData();
        }
    }

    private void GetUserData()
    {
        string _url_ = API_PREFIX + "/user";
        WebClient wc = new WebClient();
        wc.Proxy = null;
        wc.Headers.Add("jwt", ShortTermToken);
        string json = wc.DownloadString(_url_);
        user = JsonConvert.DeserializeObject<User>(json);

        if (user.banned)
        {
            //Do what you want here.
        }
    }

    private void sessTimer_Elapsed(object sender, ElapsedEventArgs e)
    {
        Console.WriteLine(IsLegit);
        if(ShortTermToken != null)
        {
            CheckSession();
        }
    }

    private void CheckSession()
    {
        string _url_ = API_PREFIX + "/checksession";
        WebClient wc = new WebClient();
        wc.Proxy = null;
        wc.Headers.Add("jwt", SessionToken);
        NameValueCollection nvc = new NameValueCollection
        {
            ["token"] = ShortTermToken
        };
        dynamic resp = JsonConvert.DeserializeObject(Encoding.Default.GetString(wc.UploadValues(_url_, nvc)));
        if(resp.success == true)
        {
            if (resp.jwt != null && resp.jwt != ShortTermToken)
            {
                ShortTermToken = resp.jwt;
                IsLegit = true;
            }
            else
            {
                IsLegit = false;
            }
        }
        else
        {
            IsLegit = false;
        }
    }

    public bool Authenticate(string secret)
    {
        string _url_ = API_PREFIX + "/authenticate";
        WebClient wc = new WebClient();
        wc.Proxy = null;
        NameValueCollection nvc = new NameValueCollection
        {
            ["secret"] = secret
        };
        string resp = Encoding.Default.GetString(wc.UploadValues(_url_, nvc));
        try
        {
            dynamic json = JsonConvert.DeserializeObject(resp);
            return false;
        }
        catch (Exception ex)
        {
            SessionToken = resp;
            IsLegit = true;
            return true;
        }
    }

    public bool Login(string username, string password)
    {
        if (IsLegit)
        {
            string _url_ = API_PREFIX + "/login";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            NameValueCollection nvc = new NameValueCollection
            {
                ["username"] = username,
                ["password"] = password
            };
            string resp = Encoding.Default.GetString(wc.UploadValues(_url_, nvc));
            dynamic json = JsonConvert.DeserializeObject(resp);
            if (json.user != null)
            {
                LoginResponse lr = JsonConvert.DeserializeObject<LoginResponse>(resp);
                ShortTermToken = lr.jwt;
                user = lr.user;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public bool Register(string username, string password, string email, string license)
    {
        if (IsLegit)
        {
            string _url_ = API_PREFIX + "/register";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            NameValueCollection nvc = new NameValueCollection
            {
                ["username"] = username,
                ["password"] = password,
                ["email"] = email,
                ["license"] = license
            };
            string resp = Encoding.Default.GetString(wc.UploadValues(_url_, nvc));
            dynamic json = JsonConvert.DeserializeObject(resp);
            return json.success;
        }
        else
            return false;
    }
    
    public string GetField(string field)
    {
        CheckSession();
        if(IsLegit)
        {
            string _url_ = API_PREFIX + $"/user/{user.id}/field/{field}";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            string resp = wc.DownloadString(_url_);
            dynamic json = JsonConvert.DeserializeObject(resp);
            return json.value;
        }
        else
        {
            return "Not Legit";
        }
    }

    public List<Tuple<string, string>> GetFields(string field)
    {
        List<Tuple<string, string>> values = new List<Tuple<string, string>>();
        CheckSession();
        if (IsLegit)
        {
            string _url_ = API_PREFIX + $"/user/{user.id}/fields";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            string resp = wc.DownloadString(_url_);
            dynamic json = JsonConvert.DeserializeObject(resp);
            for(int i = 0; i < json.Length; i++)
            {
                dynamic curr = json[i];
                values.Add(Tuple.Create<string, string>(curr.field_name, curr.field_value));
            }
            return values;
        }
        else
        {
            return null;
        }
    }
    /*
     * Username Password - Login
     * Username Password Email License - Register
     * User_ID - Get / Fields
     * User_ID Field_Name - Get / Field/Name
     * Secret - Authenticate
     * check - none
     */
}

public class User
{
    public int id { get; set; }
    public int program_id { get; set; }
    public string username { get; set; }
    public string email { get; set; }
    public string expires { get; set; }
    public int special { get; set; }
    public bool banned { get; set; }
    public bool expired { get; set; }
}

public class LoginResponse
{
    public string jwt { get; set; }
    public User user { get; set; }
}
