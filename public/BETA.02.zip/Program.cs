﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Auth auth = new Auth();
            Console.WriteLine(auth.Authenticate("hCrz0xoZDTHnzKNRpo8DJwMQPRU39SEwZZ033xHOwAfLY"));
            //Console.WriteLine(auth.Register("testAcc", "testAcc", "test@test.com", "auth-rPngNpPgRn1eGGmlJORr7"));
            Console.Write("Enter Username: "); string username = Console.ReadLine();
            Console.Write("Enter Password: "); string password = Console.ReadLine();
            bool loggedIN = auth.Login(username, password);
            if(loggedIN)
            {
                Console.WriteLine("Logged in");
            }
            else
            {
                Console.WriteLine("Failed to login");
            }
            Console.ReadLine();
        }
    }
}
