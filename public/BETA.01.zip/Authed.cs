﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net;
using System.Text;

public class Auth
{
    public User user { get; set; }
    private string SessionToken { get; set; }
    public bool Authed { get; set; }
    private int lastCheck { get; set; }
    public bool IsLegit { get; set; }
    private string API_PREFIX = "https://authed.io/api";

    private void CheckSession()
    {
        string _url_ = API_PREFIX + "/checksession";
        WebClient wc = new WebClient();
        wc.Proxy = null;
        wc.Headers.Add("jwt", SessionToken);
        NameValueCollection nvc = new NameValueCollection
        {
            ["token"] = SessionToken
        };
        dynamic resp = JsonConvert.DeserializeObject(Encoding.Default.GetString(wc.UploadValues(_url_, nvc)));
        IsLegit = resp.success;
    }

    public bool Authenticate(string secret)
    {
        string _url_ = API_PREFIX + "/authenticate";
        WebClient wc = new WebClient();
        wc.Proxy = null;
        NameValueCollection nvc = new NameValueCollection
        {
            ["secret"] = secret
        };
        string resp = Encoding.Default.GetString(wc.UploadValues(_url_, nvc));
        try
        {
            dynamic json = JsonConvert.DeserializeObject(resp);
            return false;
        }
        catch (Exception ex)
        {
            SessionToken = resp;
            return true;
        }
    }

    public bool Login(string username, string password)
    {
        CheckSession();
        if (IsLegit)
        {
            string _url_ = API_PREFIX + "/login";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            NameValueCollection nvc = new NameValueCollection
            {
                ["username"] = username,
                ["password"] = password
            };
            string resp = Encoding.Default.GetString(wc.UploadValues(_url_, nvc));
            dynamic json = JsonConvert.DeserializeObject(resp);
            if (json.username != null)
            {
                user = JsonConvert.DeserializeObject<User>(resp);
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }

    public bool Register(string username, string password, string email, string license)
    {
        CheckSession();
        if (IsLegit)
        {
            string _url_ = API_PREFIX + "/register";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            NameValueCollection nvc = new NameValueCollection
            {
                ["username"] = username,
                ["password"] = password,
                ["email"] = email,
                ["license"] = license
            };
            string resp = Encoding.Default.GetString(wc.UploadValues(_url_, nvc));
            dynamic json = JsonConvert.DeserializeObject(resp);
            return json.success;
        }
        else
            return false;
    }
    
    public string GetField(string field)
    {
        CheckSession();
        if(IsLegit)
        {
            string _url_ = API_PREFIX + $"/user/{user.user_id}/field/{field}";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            string resp = wc.DownloadString(_url_);
            dynamic json = JsonConvert.DeserializeObject(resp);
            return json.value;
        }
        else
        {
            return "Not Legit";
        }
    }

    public List<Tuple<string, string>> GetFields(string field)
    {
        List<Tuple<string, string>> values = new List<Tuple<string, string>>();
        CheckSession();
        if (IsLegit)
        {
            string _url_ = API_PREFIX + $"/user/{user.user_id}/fields";
            WebClient wc = new WebClient();
            wc.Proxy = null;
            wc.Headers.Add("jwt", SessionToken);
            string resp = wc.DownloadString(_url_);
            dynamic json = JsonConvert.DeserializeObject(resp);
            for(int i = 0; i < json.Length; i++)
            {
                dynamic curr = json[i];
                values.Add(Tuple.Create<string, string>(curr.field_name, curr.field_value));
            }
            return values;
        }
        else
        {
            return null;
        }
    }
    /*
     * Username Password - Login
     * Username Password Email License - Register
     * User_ID - Get / Fields
     * User_ID Field_Name - Get / Field/Name
     * Secret - Authenticate
     * check - none
     */
}

public class User
{
    public int user_id { get; set; }
    public string username { get; set; }
    public string email { get; set; }
    public string expires { get; set; }
    public bool banned { get; set; }
    public bool expired { get; set; }
}
