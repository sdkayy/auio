﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Auth auth = new Auth();
            Console.WriteLine(auth.Authenticate("VmtIYcbvg9Q3O5RRW09zAGArQuOLJ4tslwVnGaunN4mWE"));
            Console.WriteLine(auth.Register("test", "test", "test@test.com", "auth-9y5KnDI6rsPMH0vV7M5rU"));
            Console.WriteLine(auth.Login("test", "test"));
            Console.ReadLine();
        }
    }
}
